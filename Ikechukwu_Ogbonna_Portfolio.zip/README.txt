IKECHUKWU OGONNA — PORTFOLIO
Open index.html in a browser to preview.
Upload index.html to a static hosting service to publish.
The Work section is intentionally written as portfolio categories, not invented client projects.
Replace those cards with screenshots/links to your actual work when ready.
